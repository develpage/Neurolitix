<meta http-equiv='refresh' content='5; url=/'>
<meta charset="UTF-8" />

<?php

if (!empty($_POST['name']) AND !empty($_POST['mail']) AND !empty($_POST['message'])) 
{
    $headers = 'From:
' .
                'Reply-To: drugoisvet@gmail.com
' .
                'X-Mailer: PHP/' . phpversion();
         
    $theme = "Новое сообщение с сайта";             
             
    $letter = "Данные сообщения:";
    $letter .="
";
    $letter .="Имя: ".$_POST['name'];
    $letter .="
Email: ".$_POST['mail'];
    $letter .="
Сообщение: ".$_POST['message'];
    
    if (mail("looter-987@yandex.ru", $theme, $letter, $headers)){
      echo("Отправлено");
    } else {
      echo("Не отправлено");
    }  
              
} else {
  echo("Не отправлено");
}
?>
